# ionic-starter-deploy
A starter application with Ionic Deploy functionality to enable live updates
of your app in the app store.

## Installation
Just run:

`ionic start myApp deploy` 

`cd myApp`

`ionic upload` 

Once your app is uploaded, find it on apps.ionic.io and replace the relevent lines at the top of `/www/js/app.js` with your app ID and API key.

Congrats, you're running Ionic Deploy!
